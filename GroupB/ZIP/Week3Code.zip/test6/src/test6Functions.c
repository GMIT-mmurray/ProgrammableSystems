/*
 * test4Functions.c
 *
 *  Created on: Jan 29, 2018
 *      Author: m
 */

#include "test6.h"

void printStruct(weather* d) {
	printf("High Temp %d\n", d->highTemp);
	//d.highTemp = 60;
	printf("WinsSpeed %d\n", d->windSpeed);
}

